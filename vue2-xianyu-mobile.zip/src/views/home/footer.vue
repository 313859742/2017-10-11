<template>
  <!--底部菜单栏-->
  <ul class="bottomMenu">
    <li  class="bottomMenu-xianyuIndex">
      <span class="bottom_sprite"></span>
      <a href="#">闲鱼</a>
    </li>
    <li  class="bottomMenu-fishpond">
      <span class="bottom_sprite"></span>
      <a href="#">鱼塘</a>
    </li>
    <li  class="bottomMenu-publish">
      <span class="bottom_sprite"></span>
      <a href="#">发布</a>
    </li>
    <li  class="bottomMenu-message">
      <span class="bottom_sprite"></span>
      <a href="#">消息</a>
    </li>
    <li  class="bottomMenu-mine">
      <span class="bottom_sprite"></span>
      <a href="#">我的</a>
    </li>
  </ul>
</template>

<script>
  export default {
    name: 'footer',
    data () {
      return {

      }
    }
  }
</script>
<style>

</style>
