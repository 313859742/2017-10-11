<template>
  <!--顶部搜索框-->
  <div class="search clearfix">
    <a href="javascript:;" class="search-code"></a>
    <div class="search-box">
      惠普幽灵
    </div>
    <a href="javascript:;" class="search-menu"></a>
  </div>
</template>

<script>
  export default {
    name: 'search',
    data () {
      return {

      }
    }
  }
</script>
<style>

</style>
